document.addEventListener("DOMContentLoaded", async () => {
  const profileForm = document.getElementById("profile-form");
  if (profileForm) {
    profileForm.style.display = "none";
  }

  if (!firebase || !firebase.auth || !firebase.firestore) {
    return;
  }

  const auth = firebase.auth();
  const db = firebase.firestore();

  const popup = document.getElementById("filter-popup");
  const databaseContainer = document.getElementById("database");

  const allowed = { pink: [], blue: [], green: [], grey: [] };
  let currentEditId = null;
  let authInitialized = false;

  // Add logout functionality
  document.getElementById("logout-link")?.addEventListener("click", async (e) => {
    e.preventDefault();
    try {
      await auth.signOut();
      alert("Logged out successfully!");
    } catch (error) {
      console.error("Logout error:", error);
      alert("Error logging out. Please try again.");
    }
  });

  if (window.location.pathname.includes("profile.html")) {
    document.getElementById("profile-cancel-btn")?.addEventListener("click", (e) => {
      e.preventDefault();
      closeProfileForm();
    });
    
    document.getElementById("profile-confirm-btn")?.addEventListener("click", async (e) => {
      e.preventDefault();
      const profileForm = document.getElementById("profile-form");
      const mode = profileForm?.dataset.mode;
      if (mode === "entry") {
        await saveProfileEntry();
      } else if (mode === "edit") {
        await updateProfileEntry();
      }
      closeProfileForm();
    });
  }

  if (!window.location.pathname.includes("profile.html")) {
    document.getElementById("open-filter")?.addEventListener("click", (e) => {
      e.preventDefault();
      if (popup) popup.style.display = "block";
    });
  }

  if (window.location.pathname.includes("profile.html")) {
    document.getElementById("open-profile-form")?.addEventListener("click", (e) => {
      e.preventDefault();
      openProfileForm();
    });
  }

  const handleAuthStateChange = async (user) => {
    console.log('auth state changed!! user:', !!user, 'path:', window.location.pathname);

    updateNavigation(user);

    if (!authInitialized) {
      authInitialized = true;
      await new Promise(resolve => setTimeout(resolve, 100));
    }

    const path = window.location.pathname;

    if (!user && path.includes("profile.html")) {
      window.location.href = "index.html";
      return;
    }

    if (user && path.includes("login.html")) {
      window.location.href = "profile.html";
      return;
    }

    if (path.includes("profile.html") && user) {
      setPopupMode("entry");
      await loadUserEntries(user.uid);
    } else if (path.includes("index.html") || path === "/" || path === "" || (!path.includes("profile.html") && !path.includes("login.html"))) {
      setPopupMode("filter");
      await loadLatestEntries(10);
    }
  };

  // Set up auth state listener
  auth.onAuthStateChanged(handleAuthStateChange);

  function updateNavigation(user) {
    console.log('current user ', !!user);
    const loginLink = document.getElementById("login-link");
    const profileLink = document.getElementById("profile-link");
    const logoutLink = document.getElementById("logout-link");

    if (user) {
      if (loginLink) {
        loginLink.style.display = "none";
      }
      if (profileLink) {
        profileLink.style.display = "block";
      }
      if (logoutLink) {
        logoutLink.style.display = "block";
      }
    } else {
      if (loginLink) {
        loginLink.style.display = "block";
      }
      if (profileLink) {
        profileLink.style.display = "none";
      }
      if (logoutLink) {
        logoutLink.style.display = "none";
      }
    }
  }

  function updateAddEntryVisibility() {
    const path = window.location.pathname;
    let addEntryLink;
    
    if (path.includes("profile.html")) {
      addEntryLink = document.getElementById("open-profile-form");
    } else {
      addEntryLink = document.getElementById("open-filter");
    }
    
    if (path.includes("profile.html") && addEntryLink) {
      const editButtons = document.querySelectorAll('.edit-btn');
      if (editButtons.length > 0) {
        addEntryLink.style.display = "none";
      } else {
        addEntryLink.style.display = "block";
      }
    }
  }

  function parseCSV(text) {
    const rows = [];
    let currentRow = [];
    let currentValue = "";
    let inQuotes = false;

    for (let i = 0; i < text.length; i++) {
      const char = text[i];
      if (char === '"') {
        if (inQuotes && text[i + 1] === '"') {
          currentValue += '"';
          i++;
        } else {
          inQuotes = !inQuotes;
        }
      } else if (char === ',' && !inQuotes) {
        currentRow.push(currentValue);
        currentValue = "";
      } else if ((char === '\n' || char === '\r') && !inQuotes) {
        if (currentValue || currentValue === "") {
          currentRow.push(currentValue);
          currentValue = "";
        }
        if (currentRow.length) {
          rows.push(currentRow);
          currentRow = [];
        }
      } else {
        currentValue += char;
      }
    }
    if (currentValue || currentRow.length) {
      currentRow.push(currentValue);
      rows.push(currentRow);
    }
    return rows;
  }

  function sanitize(str) {
    return (str || "")
      .replace(/<[^>]*>/g, "")
      .replace(/&[^;]+;/g, "")
      .trim();
  }

  function addToDatalist(datalistId, value) {
    const datalist = document.getElementById(datalistId);
    if (!datalist) return;
    const option = document.createElement("option");
    option.value = value;
    datalist.appendChild(option);
  }

  function createChipHTML(label, stars, colorId) {
    return `
      ${label}
      <span class="star-controls">
          ★<span class="star-count">${stars}</span>
          <button class="star-button" data-action="up">+</button>
          <button class="star-button" data-action="down">−</button>
      </span>
      <button class="remove-button" title="Remove">✕</button>
    `;
  }

  function attachChipEvents(chipEl, container) {
    chipEl.querySelector(".star-controls").addEventListener("click", (evt) => {
      if (evt.target.tagName !== "BUTTON") return;
      const span = chipEl.querySelector(".star-count");
      let count = parseInt(span.textContent);
      if (evt.target.dataset.action === "up" && count < 9) count++;
      else if (evt.target.dataset.action === "down" && count > 1) count--;
      span.textContent = count;
    });

    chipEl.querySelector(".remove-button").addEventListener("click", () => {
      container.removeChild(chipEl);
    });
  }

  function addChip(containerId, colorId, label, stars = 1) {
    const container = document.getElementById(containerId);
    if (!container) return;
    const chip = document.createElement("div");
    chip.className = "spark";
    chip.id = colorId;
    chip.innerHTML = createChipHTML(label, stars, colorId);
    attachChipEvents(chip, container);
    container.appendChild(chip);
  }

  function clearChipList(containerId) {
    const container = document.getElementById(containerId);
    if (container) container.innerHTML = "";
  }

  function setupSparkInput(inputId, containerId, colorId, max = Infinity) {
    const input = document.getElementById(inputId);
    const container = document.getElementById(containerId);

    if (!input || !container) return;

    input.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        const value = input.value.trim();
        if (!value || container.children.length >= max) return;
        if (!allowed[colorId].includes(value)) {
          input.value = "";
          return;
        }
        addChip(containerId, colorId, value, 1);
        input.value = "";
      }
    });
  }

  function getSparkNameStars(containerId) {
    const container = document.getElementById(containerId);
    if (!container) return [];
    return Array.from(container.children).map(chip => {
      const name = chip.childNodes[0].textContent.trim();
      const stars = parseInt(chip.querySelector(".star-count").textContent);
      return { name, stars };
    });
  }

  async function loadFactors() {
    try {
      const res = await fetch("db/factors_en.csv"); // Fixed path
      const text = await res.text();
      const rows = parseCSV(text);
      const factorsByType = { pink: [], blue: [], green: [], grey: [] };

      rows.forEach((row) => {
        const type = sanitize(row[1]);
        const spark = sanitize(row[2]);
        if (!spark) return;

        let color;
        switch (type) {
          case "1": color = "pink"; break;
          case "2": color = "blue"; break;
          case "3": color = "green"; break;
          default:  color = "grey";
        }
        factorsByType[color].push(spark);
      });

      Object.keys(factorsByType).forEach(color => {
        factorsByType[color].sort((a, b) => a.localeCompare(b));
        factorsByType[color].forEach(spark => {
          addToDatalist(`${color}-sparks-options`, spark);
          allowed[color].push(spark);
        });
      });
    } catch (err) {
      console.error("Error loading factors_en.csv:", err);
    }
  }

  async function loadSimpleList(csvFile, datalistId) {
    try {
      const res = await fetch(csvFile);
      const text = await res.text();
      const rows = parseCSV(text);
      const names = rows.map(r => sanitize(r[0])).filter(Boolean);
      names.sort((a, b) => a.localeCompare(b));
      names.forEach(name => addToDatalist(datalistId, name));
    } catch (err) {
      console.error(`Error loading ${csvFile}:`, err);
    }
  }

  function renderEntry(entryData, docId, allowManage = false) {
    if (!databaseContainer) return;
    
    const { trainerId, umaName, sparks } = entryData;
    const displayId = (trainerId || "").replace(/(\d{3})(?=\d)/g, "$1 ").trim();
    const sparkTypes = ["pink", "blue", "green", "grey"];

    const sparksHtml = sparkTypes.map(color => {
      const sparkArray = sparks?.[color];
      if (!Array.isArray(sparkArray)) return "";
      
      return sparkArray.length > 0 ? `
        <div class="spark-row">
          ${sparkArray.map(s => `
            <div class="spark" id="${color}">
              ${s.name} ★${s.stars}
            </div>
          `).join("")}
        </div>
      ` : "";
    }).join("");

    const article = document.createElement("article");
    article.innerHTML = `
      <header id="userid">${displayId}</header>
      <div class="flex">
        <div class="img"><img src="img/chara_stand_placeholder.png" alt=""></div>
        <div class="content">
          <b class="item-name">${umaName || ""}</b>
          ${sparksHtml}
          ${allowManage ? `
            <div class="row" style="gap:.5rem;margin-top:.5rem">
              <button class="edit-btn">Edit</button>
              <button class="delete-btn">Delete</button>
            </div>` : ""}
        </div>
      </div>
    `;

    if (allowManage) {
      article.querySelector(".delete-btn").addEventListener("click", async () => {
        await deleteUserEntry(docId);
      });

      article.querySelector(".edit-btn").addEventListener("click", () => {
        openEditPopup(docId, entryData);
      });
    }

    databaseContainer.appendChild(article);
  }

  async function loadLatestEntries(limitCount = 10) {
    try {
      if (databaseContainer) databaseContainer.innerHTML = "";
      const snapshot = await db.collection("entries").get();
  
      const entries = [];
      snapshot.forEach(doc => entries.push({ id: doc.id, data: doc.data() }));
      
      entries.sort((a, b) => {
        if (!a.data.timestamp && !b.data.timestamp) return 0;
        if (!a.data.timestamp) return 1;
        if (!b.data.timestamp) return -1;
        
        return b.data.timestamp.seconds - a.data.timestamp.seconds || 
               b.data.timestamp.nanoseconds - a.data.timestamp.nanoseconds;
      });
  
      const latestEntries = entries.slice(0, limitCount);
  
      latestEntries.forEach(entry => 
        renderEntry(entry.data, entry.id, false)
      );
    } catch (err) {
      console.error("Error loading entries:", err);
      if (databaseContainer) {
        databaseContainer.innerHTML = "<p>Oops, looks like we failed to load the database. Check back later da zo</p>";
      }
    }
  }

  async function loadUserEntries(userId) {
    try {
      if (databaseContainer) databaseContainer.innerHTML = "";
      
      // First try with orderBy, if it fails, fall back to simple where query
      let snapshot;
      try {
        snapshot = await db.collection("entries")
          .where("userId", "==", userId)
          .orderBy("timestamp", "desc")
          .get();
      } catch (indexError) {
        console.log("Firestore index not available, using simple query:", indexError);
        // Fallback to simple query without orderBy
        snapshot = await db.collection("entries")
          .where("userId", "==", userId)
          .get();
      }
      
      if (snapshot.empty) {
        if (databaseContainer) {
          databaseContainer.innerHTML = "<p>You haven't set up your profile yet!</p>";
        }
      } else {
        // If we used the fallback query, sort manually
        const entries = [];
        snapshot.forEach(doc => entries.push({ id: doc.id, data: doc.data() }));
        
        // Sort by timestamp manually if needed
        entries.sort((a, b) => {
          if (!a.data.timestamp && !b.data.timestamp) return 0;
          if (!a.data.timestamp) return 1;
          if (!b.data.timestamp) return -1;
          
          return b.data.timestamp.seconds - a.data.timestamp.seconds || 
                 b.data.timestamp.nanoseconds - a.data.timestamp.nanoseconds;
        });
        
        entries.forEach(entry => renderEntry(entry.data, entry.id, true));
      }
      
      updateAddEntryVisibility();
    } catch (err) {
      console.error("Error loading user entries:", err);
      if (databaseContainer) {
        databaseContainer.innerHTML = "<p>Oops, looks like we failed to load your profile. Try setting one!</p>";
      }
    }
  }

  async function applyFilterFromUI() {
    try {
      const pinkFilter = getSparkNameStars("pink-spark-list");
      const blueFilter = getSparkNameStars("blue-spark-list");
      const greenFilter = getSparkNameStars("green-spark-list");
      const greyFilter = getSparkNameStars("grey-spark-list");

      if (pinkFilter.length === 0 && blueFilter.length === 0 && 
          greenFilter.length === 0 && greyFilter.length === 0) {
        await loadLatestEntries(10);
        return;
      }
  
      const snapshot = await db.collection("entries").get();
      
      if (databaseContainer) databaseContainer.innerHTML = "";
      
      const entries = [];
      snapshot.forEach(doc => entries.push({ id: doc.id, data: doc.data() }));

      entries.sort((a, b) => {
        if (!a.data.timestamp && !b.data.timestamp) return 0;
        if (!a.data.timestamp) return 1;
        if (!b.data.timestamp) return -1;

        return b.data.timestamp.seconds - a.data.timestamp.seconds || 
               b.data.timestamp.nanoseconds - a.data.timestamp.nanoseconds;
      });
  
      const filteredEntries = entries.filter(entry => {
        const sparks = entry.data.sparks || {};

        const checkFactors = (filterArray, entryArray) => {
          if (filterArray.length === 0) return true;
          if (!entryArray) return false;
          
          return filterArray.every(filterFactor => 
            entryArray.some(entryFactor => 
              entryFactor.name === filterFactor.name && 
              entryFactor.stars === filterFactor.stars
            )
          );
        };
  
        return checkFactors(pinkFilter, sparks.pink) &&
               checkFactors(blueFilter, sparks.blue) &&
               checkFactors(greenFilter, sparks.green) &&
               checkFactors(greyFilter, sparks.grey);
      });
  
      filteredEntries.forEach(entry => 
        renderEntry(entry.data, entry.id, false)
      );
    } catch (err) {
      console.error("filter err ", err);
      alert("Filter error, pls try again");
    }
  }
  
  function normalizedTrainerId(raw) {
    return (raw || "").replace(/\D/g, "");
  }

  async function saveProfileEntry() {
    try {
      const user = auth.currentUser;
      if (!user) return alert("not signed in, try signing in");
  
      const existingSnapshot = await db.collection("entries")
        .where("userId", "==", user.uid)
        .limit(1)
        .get();
  
      const trainerIdEl = document.getElementById("trainer-id");
      const umaNameEl = document.getElementById("uma-name");
      
      if (!trainerIdEl || !umaNameEl) {
        return;
      }
  
      const trainerId = normalizedTrainerId(trainerIdEl.value);
      const umaName = umaNameEl.value.trim();
  
      if (!trainerId || !umaName) return alert("Trainer ID and Uma name required");
  
      const sparks = {
        pink: getSparkNameStars("pink-spark-list"),
        blue: getSparkNameStars("blue-spark-list"),
        green: getSparkNameStars("green-spark-list"),
        grey: getSparkNameStars("grey-spark-list")
      };
  
      const entryData = {
        userId: user.uid,
        trainerId,
        umaName,
        sparks,
        timestamp: firebase.firestore.FieldValue.serverTimestamp()
      };
  
      if (!existingSnapshot.empty) {
        const docId = existingSnapshot.docs[0].id;
        await db.collection("entries").doc(docId).update(entryData);
        alert("Profile updated successfully!");
      } else {
        await db.collection("entries").add(entryData);
        alert("Profile created successfully!");
      }
  
      await loadUserEntries(user.uid);
    } catch (err) {
      console.error("err ", err);
      alert("Entry update failed. Try again?");
    }
  }

  async function updateProfileEntry() {
    try {
      const user = auth.currentUser;
      if (!user) return alert("Not signed in!");
      if (!currentEditId) return;

      const trainerIdEl = document.getElementById("trainer-id");
      const umaNameEl = document.getElementById("uma-name");
      
      if (!trainerIdEl || !umaNameEl) {
        alert("Form elements not found");
        return;
      }
  
      const trainerId = normalizedTrainerId(trainerIdEl.value);
      const umaName = umaNameEl.value.trim();
      if (!trainerId || !umaName) return alert("Trainer ID and Uma name required");
  
      const sparks = {
        pink: getSparkNameStars("pink-spark-list"),
        blue: getSparkNameStars("blue-spark-list"),
        green: getSparkNameStars("green-spark-list"),
        grey: getSparkNameStars("grey-spark-list")
      };
  
      await db.collection("entries").doc(currentEditId).update({
        trainerId,
        umaName,
        sparks,
        timestamp: firebase.firestore.FieldValue.serverTimestamp()
      });
  
      currentEditId = null;
      await loadUserEntries(user.uid);
    } catch (err) {
      console.error("err ", err);
      alert("Entry update failed. Try again?");
    }
  }

  async function deleteUserEntry(docId) {
    try {
      const user = auth.currentUser;
      if (!user) return alert("Not signed in!");

      if (confirm("Delete your entry? This cannot be reversed!!")) {
        await db.collection("entries").doc(docId).delete();
        alert("Entry deleted!");
        await loadUserEntries(user.uid);
      }
    } catch (err) {
      console.error("deletion err ", err);
      alert("Error deleting entry. Try again pien.");
    }
  }

  function setPopupMode(mode) {
    const popup = document.getElementById("filter-popup") || document.getElementById("profile-form");
    if (!popup) return;
    
    popup.dataset.mode = mode;
    const title = document.getElementById("popup-title");
    const profileFields = popup.querySelector(".profile-fields");
    
    if (mode === "filter") {
      if (title) title.textContent = "Filter Entries";
      if (profileFields) profileFields.style.display = "none";
    } else if (mode === "entry") {
      if (title) title.textContent = "Add Entry";
      if (profileFields) profileFields.style.display = "block";
      currentEditId = null;

      const trainerIdEl = document.getElementById("trainer-id");
      const umaNameEl = document.getElementById("uma-name");
      if (trainerIdEl) trainerIdEl.value = "";
      if (umaNameEl) umaNameEl.value = "";
      clearChipList("pink-spark-list");
      clearChipList("blue-spark-list");
      clearChipList("green-spark-list");
      clearChipList("grey-spark-list");

    } else if (mode === "edit") {
      if (title) title.textContent = "Edit Entry";
      if (profileFields) profileFields.style.display = "block";
    }
  }

  function populatePopupFromEntry(entry) {
    const trainerIdEl = document.getElementById("trainer-id");
    const umaNameEl = document.getElementById("uma-name");
    if (trainerIdEl) trainerIdEl.value = entry.trainerId || "";
    if (umaNameEl) umaNameEl.value = entry.umaName || "";

    clearChipList("pink-spark-list");
    clearChipList("blue-spark-list");
    clearChipList("green-spark-list");
    clearChipList("grey-spark-list");

    ["pink", "blue", "green", "grey"].forEach(color => {
      const listId = `${color}-spark-list`;
      const arr = entry?.sparks?.[color] || [];
      arr.forEach(s => addChip(listId, color, s.name, s.stars));
    });
  }

  function openEditPopup(docId, entryData) {
    currentEditId = docId;
    setPopupMode("edit");
    populatePopupFromEntry(entryData);
    const profileForm = document.getElementById("profile-form");
    if (profileForm) {
      profileForm.style.display = "block";
    }
  }

  function openProfileForm() {
    const profileForm = document.getElementById("profile-form");
    if (profileForm) {
      profileForm.style.display = "block";
      setPopupMode("entry");
    }
  }
  
  window.closeProfileForm = function() {
    const profileForm = document.getElementById("profile-form");
    if (profileForm) {
      profileForm.style.display = "none";
    }
  }

  window.closeFilter = () => { 
    const popup = document.getElementById("filter-popup");
    if (popup) popup.style.display = "none";
  };

  window.applyFilter = async () => {
    await applyFilterFromUI();
    closeFilter();
  };

  document.getElementById("popup-confirm-btn")?.addEventListener("click", async () => {
    const popup = document.getElementById("filter-popup");
    if (!popup) return;
    const mode = popup.dataset.mode;
    if (mode === "filter") {
      await applyFilterFromUI();
    }
    closeFilter();
  });

  try {
    await Promise.all([
      loadFactors(),
      loadSimpleList("db/star_umamusume.csv", "umamusume-options"), // Fixed path
      loadSimpleList("db/sapoka.csv", "support-card-options") // Fixed path
    ]);

    setupSparkInput("pink-sparks", "pink-spark-list", "pink", 3);
    setupSparkInput("blue-sparks", "blue-spark-list", "blue", 3);
    setupSparkInput("green-sparks", "green-spark-list", "green", 1);
    setupSparkInput("grey-sparks", "grey-spark-list", "grey");
    
  } catch (err) {
    console.error("init err ", err);
  }
});